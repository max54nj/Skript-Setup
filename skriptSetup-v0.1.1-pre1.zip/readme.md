# Basic Skript Setup

> **Author**: Max54nj \
> **Sponsor**: [NrwPlay](https://nrwplay.de/) \
> **Website**: [max54nj.de](https://max54nj.de)

# Requirements

## Plugins

-   [Skript](https://github.com/SkriptLang/Skript)
-   Permission system like [Luckperms](https://luckperms.net/download)
-   [Skbee](https://github.com/ShaneBeee/SkBee)
-   [skript-placeholders](https://github.com/APickledWalrus/skript-placeholders)


# Modules

## Chat

### Requirements
-   [Vault](https://www.spigotmc.org/resources/vault.34315/)


## Lifesteal

### Requirements
-   [SkJson](https://github.com/cooffeeRequired/skJson)
